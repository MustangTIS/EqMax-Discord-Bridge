import os
import time
import requests
import json
import re
import psutil  # 要: pip install psutil

# --- EqMaxの健康管理 (見張り番) ---
def maintain_eqmax_health(exe_path, check_full=False):
    process_name = "EqMax.exe"
    target_proc = None

    # プロセス一覧を取得してEqMaxを探す
    for proc in psutil.process_iter(['name']):
        try:
            if proc.info['name'] == process_name:
                target_proc = proc
                break
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    # 1. そもそもプロセスがいないなら、即座に叩き起こす
    if target_proc is None:
        print(f"[{time.strftime('%H:%M:%S')}] EqMaxが見つかりません。起動します。")
        os.startfile(exe_path)
        return

    # 2. 10秒に1回の「精密検査」モードの時だけ実行
    if check_full:
        try:
            # 応答チェック (フリーズ・ゾンビ対策)
            if not target_proc.is_running() or target_proc.status() == psutil.STATUS_ZOMBIE:
                print(f"[{time.strftime('%H:%M:%S')}] EqMaxが応答不能です。再起動します。")
                target_proc.kill()
                time.sleep(2)
                os.startfile(exe_path)
                return

            # メモリチェック (1024MB超過で再起動)
            mem_mb = target_proc.memory_info().rss / (1024 * 1024)
            if mem_mb > 1024:
                print(f"[{time.strftime('%H:%M:%S')}] EqMaxメモリ超過({mem_mb:.1f}MB): 再起動します。")
                target_proc.kill()
                time.sleep(2)
                os.startfile(exe_path)
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            os.startfile(exe_path)

# --- 設定の読み込み ---
def load_config():
    config = {
        "destinations": [],
        "eqmax_dir": "C:\\EqMax_Win64"
    }
    if os.path.exists("config.json"):
        try:
            with open("config.json", "r", encoding="utf-8") as f:
                config.update(json.load(f))
        except Exception as e: print(f"設定失敗: {e}")
    return config

config = load_config()
LOG_FILE = os.path.join(config["eqmax_dir"], "Twitter.log")

def get_alert_details(text_block):
    """テキストから情報を抽出。津波監視もここで行う"""
    if "緊急地震速報：" not in text_block:
        return None, None, None

    lines = text_block.strip().split('\n')
    shindo, mag_str, mag_val = "不明", "不明", 0.0
    clean_lines, found_essential = [], False 
    
    for line in lines:
        line = line.strip()
        if any(x in line for x in ["PostTweet", "TTwitter", "=", "remaining"]): continue
        if not line: continue
        if "尚、これは" in line: break
        
        if "震源地：" in line:
            found_essential = True
        if "推定最大震度：" in line:
            shindo = line.split("：")[1].strip()
        if "マグニチュード：" in line:
            mag_str = line.split("：")[1].strip()
            m_match = re.search(r"(\d+\.\d+|\d+)", mag_str)
            if m_match:
                mag_val = float(m_match.group(1))
                found_essential = True
        clean_lines.append(line)

    if not found_essential:
        return None, None, None

    description = "\n".join(clean_lines)
    title = f"[EqMax] EEW Alert📢 【最大震度 {shindo} / {mag_str}】"

    # 震度カラー設定
    color = 0x808080
    color_map = {"7": 0xFF0000, "6強": 0xFF4500, "6弱": 0xFF8C00, "5強": 0xFFA500, 
                 "5弱": 0xFFFF00, "4": 0x00FF00, "3": 0x00FFFF, "2": 0x1E90FF, "1": 0xFFFFFF}
    for k, v in color_map.items():
        if k in shindo:
            color = v
            break
    
    # 津波監視ロジック
    tsunami_keywords = ["海域", "近海", "沖", "灘", "湾"]
    if any(k in description for k in tsunami_keywords):
        if mag_val >= 7.5:
            description = "🚨**【巨大地震・大津波警戒】大規模な津波が発生する恐れがあります。ただちに海岸から離れ、高い場所へ避難してください。**\n\n" + description
            color = 0xff0000
        elif mag_val >= 6.0:
            description = "⚠️**大規模な海域地震です。津波の発生に厳重に警戒してください。**\n\n" + description
            color = 0xffa500
        else:
            description = "ℹ️海域で地震が発生しました。念のため津波の有無に注意してください。\n\n" + description

    return title, description, color

def process_log_update(content):
    pattern = re.compile(r"(緊急地震速報：.*?)(C:\\.*?\.png)", re.DOTALL)
    matches = pattern.findall(content)
    if not matches: return

    full_text, image_path = matches[-1]
    title, description, color = get_alert_details(full_text)
    if not title: return

    for dest in config.get("destinations", []):
        url, style = dest.get("url"), dest.get("style", "embed")
        if not url or "http" not in url: continue

        if style == "embed":
            payload = {"embeds": [{"title": title, "description": description, "color": color, "image": {"url": "attachment://image.png"}, "footer": {"text": "EqMax Realtime Alert"}}]}
        else:
            compact_desc = re.sub(r"( / )+", " / ", description.replace("\n", " / ")).strip(" / ")
            payload = {"content": f"📢 **{title}**\n`{compact_desc}`"}

        try:
            if os.path.exists(image_path):
                with open(image_path, "rb") as f:
                    requests.post(url, data={"payload_json": json.dumps(payload)}, files={"file": ("image.png", f, "image/png")})
            else:
                requests.post(url, json=payload)
        except Exception as e: print(f"送信失敗: {e}")

# --- メイン監視ループ ---
def watch_log():
    if not config.get("destinations"):
        print("エラー: 送信先が設定されていません。")
        return

    eqmax_exe = os.path.join(config["eqmax_dir"], "EqMax.exe")
    print(f"監視システム起動: {LOG_FILE}")
    last_size = os.path.getsize(LOG_FILE) if os.path.exists(LOG_FILE) else 0
    pending_block = ""
    health_check_counter = 0

    while True:
        try:
            health_check_counter += 1
            
            # --- 生存確認と精密検査の実行 ---
            # 10秒に1回は精密検査、それ以外は存在確認のみ
            if health_check_counter >= 10:
                maintain_eqmax_health(eqmax_exe, check_full=True)
                health_check_counter = 0
            else:
                maintain_eqmax_health(eqmax_exe, check_full=False)

            # --- ログ監視 ---
            if not os.path.exists(LOG_FILE):
                last_size = 0
                time.sleep(1)
                continue

            current_size = os.path.getsize(LOG_FILE)
            if current_size < last_size:
                last_size, pending_block = 0, ""
            
            if current_size > last_size:
                with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
                    f.seek(last_size)
                    new_lines = f.readlines()
                for line in new_lines:
                    line = line.strip()
                    if not line or "PostTweet - passed:" in line:
                        pending_block = ""
                        continue
                    if "緊急地震速報：" in line:
                        pending_block = line + "\n"
                    elif pending_block:
                        pending_block += line + "\n"
                        if ".png" in line and "C:\\" in line:
                            time.sleep(1)
                            process_log_update(pending_block)
                            pending_block = ""
                last_size = current_size
        except Exception as e:
            print(f"ループエラー: {e}")
        
        time.sleep(1) # 1秒待機

if __name__ == "__main__":
    watch_log()