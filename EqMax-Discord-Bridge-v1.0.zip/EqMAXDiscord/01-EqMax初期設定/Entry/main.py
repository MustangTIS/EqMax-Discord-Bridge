import customtkinter as ctk
from tkinter import filedialog, messagebox
import json
import os
from datetime import datetime

class EqMaxSetupPatcher(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("EqMax Discord連携 - 初期設定パッチ")
        self.geometry("550x650")

        self.label_path = ctk.CTkLabel(self, text="1. EqMax.exe を選択してください:")
        self.label_path.pack(pady=(20, 0))
        self.path_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.path_frame.pack(pady=5)
        self.entry_path = ctk.CTkEntry(self.path_frame, width=350)
        self.entry_path.pack(side="left", padx=(0, 5))
        self.btn_browse = ctk.CTkButton(self.path_frame, text="選択...", width=80, command=self.browse_file)
        self.btn_browse.pack(side="left")

        # 注意書き
        self.info_frame = ctk.CTkFrame(self)
        self.info_frame.pack(pady=20, padx=20, fill="x")
        info_text = (
            "【セットアップ内容】\n\n"
            "・既存のTwitter(X)設定をリセット（再認証が必要になります）\n"
            "・投稿フォーマットを最新の指定形式に書き換え\n"
            "・EqMaxフォルダ内に Twitter.log (0KB) を作成\n"
            "・UTF-8 BOM形式を維持して保存"
        )
        self.label_info = ctk.CTkLabel(self.info_frame, text=info_text, justify="left")
        self.label_info.pack(pady=10, padx=10)

        self.var_agree = ctk.StringVar(value="off")
        self.check_agree = ctk.CTkCheckBox(self, text="上記の内容に同意してセットアップを実行する", variable=self.var_agree)
        self.check_agree.pack(pady=10)

        self.btn_run = ctk.CTkButton(self, text="セットアップを実行", fg_color="darkblue", height=60, command=self.run_patch)
        self.btn_run.pack(pady=20)

        self.log_view = ctk.CTkTextbox(self, width=500, height=120)
        self.log_view.pack(pady=10)

    def browse_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("EqMax.exe", "EqMax.exe")])
        if file_path:
            self.entry_path.delete(0, "end")
            self.entry_path.insert(0, os.path.dirname(file_path))

    def write_log(self, text):
        self.log_view.insert("end", f"{datetime.now().strftime('%H:%M:%S')} : {text}\n")
        self.log_view.see("end")

    def run_patch(self):
        if self.var_agree.get() == "off":
            messagebox.showwarning("確認", "同意チェックを入れてください。")
            return
            
        path = self.entry_path.get().strip()
        ini_path = os.path.join(path, "EqMax.ini")
        if not path or not os.path.exists(ini_path):
            self.write_log("エラー: EqMax.iniが見つかりません。")
            return

        # 1. Twitter.log (0KB) 作成
        try:
            with open(os.path.join(path, "Twitter.log"), 'wb') as f:
                pass
            self.write_log("Twitter.log (0KB) を作成しました。")
        except Exception as e:
            self.write_log(f"ログ作成失敗: {e}")

        # 2. v2_Tokens.json 作成
        self.create_initial_json(path)
        
        # 3. INI更新
        self.patch_ini_final(ini_path)
        
        messagebox.showinfo("完了", "セットアップが完了しました。")
        self.destroy()

    def create_initial_json(self, path):
        json_path = os.path.join(path, "v2_Tokens.json")
        now_iso = datetime.now().strftime("%Y-%m-%dT%H:%M:%S.000+09:00")
        data = {
            "appname": "EqMax_Discord",
            "client_id": "dummy", "client_id_secret": "dummy",
            "scopes": "tweet.read tweet.write users.read offline.access media.write",
            "refresh_token": "dummy", "bearer_token": "dummy",
            "bearer_token_obtained_at": now_iso
        }
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=4)
        self.write_log("v2_Tokens.json を初期化しました。")

    def patch_ini_final(self, ini_path):
        with open(ini_path, 'r', encoding='utf-8-sig') as f:
            lines = f.readlines()

        # 指定された最新のEEWItemsフォーマット
        # 文字列としての \t を使用
        S = "\\t"
        items = [
            "", "[緊急地震速報：]", "報番号", "最終報", "警報", "<改行>",
            "[震源地：]", "震央名", "[(]", "緯度経度", "[)]", "<改行>",
            "[マグニチュード：M]", "マグニチュード", "<改行>",
            "[深さ：]", "深さ", "<改行>",
            "[推定最大震度：]", "最大震度", "<改行>", "<改行>", "画像"
        ]
        eew_items_line = "EEWItems=" + S.join(items)

        updates = {
            "TwitterBotEnabled": "1",
            "EEWEnabled": "1",
            "Enable": "1",
            "v2": "1",
            "AppName": "EqMax_Discord",
            "AutoPost": "1",
            "UploadImage": "1",
            "AutoCapture": "1",
            "Format": "緊急地震速報：$Point$ $MaxShindo$ $Mag$ $Depth$",
            "ClientID": "dummy", "ClientSecret": "dummy",
            "RefreshToken": "dummy", "BearerToken": "dummy",
            "ConsumerKey": "", "ConsumerKeySecret": "", 
            "AccessToken": "", "AccessTokenSecret": ""
        }

        new_lines = []
        applied_keys = set()
        
        for line in lines:
            line_s = line.strip()
            found = False
            
            if line_s.startswith("EEWItems="):
                new_lines.append(eew_items_line + "\n")
                applied_keys.add("EEWItems")
                found = True
            else:
                for k, v in updates.items():
                    if line_s.startswith(k + "="):
                        new_lines.append(f"{k}={v}\n")
                        applied_keys.add(k)
                        found = True
                        break
            
            if not found:
                new_lines.append(line if line.endswith('\n') else line + '\n')

        if "EEWItems" not in applied_keys:
            new_lines.append(eew_items_line + "\n")
        for k, v in updates.items():
            if k not in applied_keys:
                new_lines.append(f"{k}={v}\n")

        # UTF-8 BOM付きで保存
        with open(ini_path, 'w', encoding='utf-8-sig', newline='\r\n') as f:
            f.writelines(new_lines)
            
        self.write_log("INIファイルを最新フォーマットで更新しました。")

if __name__ == "__main__":
    EqMaxSetupPatcher().mainloop()