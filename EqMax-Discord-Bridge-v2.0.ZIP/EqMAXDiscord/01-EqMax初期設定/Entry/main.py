import customtkinter as ctk
from tkinter import filedialog, messagebox
import json
import os
import webbrowser
from datetime import datetime

class EqMaxSetupPatcher(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("EqMax Discord連携 - 初期設定パッチ")
        self.geometry("550x920")

        # 公式サイトボタン
        self.btn_web = ctk.CTkButton(self, text="EqMax公式サイトを開く (DL・最新情報の確認)", 
                                     fg_color="transparent", border_width=1,
                                     command=lambda: webbrowser.open("https://melanion.info/eqmax/"))
        self.btn_web.pack(pady=(20, 0))

        # 1. フォルダ選択
        self.label_path = ctk.CTkLabel(self, text="1. EqMax.exe を選択してください:")
        self.label_path.pack(pady=(10, 0))
        self.path_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.path_frame.pack(pady=5)
        self.entry_path = ctk.CTkEntry(self.path_frame, width=350)
        self.entry_path.pack(side="left", padx=(0, 5))
        self.btn_browse = ctk.CTkButton(self.path_frame, text="選択...", width=80, command=self.browse_file)
        self.btn_browse.pack(side="left")

        # 2. セットアップオプション
        self.option_frame = ctk.CTkFrame(self)
        self.option_frame.pack(pady=10, padx=20, fill="x")
        
        self.label_opt = ctk.CTkLabel(self.option_frame, text="2. セットアップオプション:", font=("", 12, "bold"))
        self.label_opt.pack(pady=(10, 5), padx=20, anchor="w")

        # 【選択】Twitter認証情報の初期化
        self.var_tw_reset = ctk.BooleanVar(value=True)
        self.check_tw_reset = ctk.CTkCheckBox(self.option_frame, 
                                             text="Twitter(X)機能を現在使用していない\n(認証情報を初期化し、Discord専用として構成する)", 
                                             variable=self.var_tw_reset)
        self.check_tw_reset.pack(pady=10, padx=20, anchor="w")

        # 【強制】共通設定（解除不可）
        self.var_ini_base = ctk.BooleanVar(value=True)
        self.check_ini_base = ctk.CTkCheckBox(self.option_frame, 
                                             text="共通設定を適用 (EEWItems/連携有効化)\n※解除不可", 
                                             variable=self.var_ini_base, state="disabled")
        self.check_ini_base.pack(pady=5, padx=20, anchor="w")

        # 【強制】キャプチャ保存（解除不可）
        self.var_cap = ctk.BooleanVar(value=True)
        self.check_cap = ctk.CTkCheckBox(self.option_frame, 
                                         text="自動キャプチャ・画像保存を有効化\n※解除不可", 
                                         variable=self.var_cap, state="disabled")
        self.check_cap.pack(pady=5, padx=20, anchor="w")

        # 【選択】通知間引き設定
        self.var_check_count = ctk.BooleanVar(value=True) # デフォルトON(間引きなし)
        self.check_count = ctk.CTkCheckBox(self.option_frame, 
                                          text="通知の間引きを無効にする (全報通知)\n(※チェックなし：EqMax独自判定で通知を制限する)", 
                                          variable=self.var_check_count)
        self.check_count.pack(pady=10, padx=20, anchor="w")

        # 3. 表示例エリア
        self.example_frame = ctk.CTkFrame(self, fg_color="#2b2b2b")
        self.example_frame.pack(pady=10, padx=20, fill="x")
        self.label_example_title = ctk.CTkLabel(self.example_frame, text="【Discord通知レイアウト例】", font=("", 10, "bold"))
        self.label_example_title.pack(pady=(5, 0))
        
        example_text = (
            "緊急地震速報：第5報(終)予報\n"
            "震源地：奄美大島近海(28.0N 129.2E)\n"
            "マグニチュード：M3.8\n"
            "深さ：10km\n"
            "推定最大震度：3\n\n"
            "(ここに画像ファイルが添付されます)"
        )
        self.label_example = ctk.CTkLabel(self.example_frame, text=example_text, justify="left", font=("Consolas", 11) if os.name == 'nt' else ("monospace", 11))
        self.label_example.pack(pady=10, padx=10)

        # 実行ボタン
        self.btn_run = ctk.CTkButton(self, text="セットアップを実行", fg_color="darkblue", height=60, 
                                     command=self.run_patch, state="disabled")
        self.btn_run.pack(pady=10)

        # ログ表示
        self.log_view = ctk.CTkTextbox(self, width=500, height=100)
        self.log_view.pack(pady=10)

    def browse_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("EqMax.exe", "EqMax.exe")])
        if file_path:
            self.entry_path.delete(0, "end")
            self.entry_path.insert(0, os.path.dirname(file_path))
            self.btn_run.configure(state="normal")

    def write_log(self, text):
        self.log_view.insert("end", f"{datetime.now().strftime('%H:%M:%S')} : {text}\n")
        self.log_view.see("end")

    def run_patch(self):
        path = self.entry_path.get().strip()
        ini_path = os.path.join(path, "EqMax.ini")
        if not path or not os.path.exists(ini_path):
            self.write_log("エラー: EqMax.iniが見つかりません。")
            return

        # --- 追加：EqMax.exe を強制終了 ---
        try:
            self.write_log("EqMaxのプロセスを確認中...")
            # 実行中のプロセスを強制終了（見つからなくてもエラーを出さない設定）
            os.system('taskkill /F /IM EqMax.exe /T >nul 2>&1')
            self.write_log("EqMaxを強制終了しました（起動していた場合）。")
        except Exception as e:
            self.write_log(f"プロセス終了中にエラー: {e}")

        # 基本処理：Twitter.logの作成
        try:
            with open(os.path.join(path, "Twitter.log"), 'wb') as f: pass
            self.write_log("Twitter.log を作成/更新しました。")
        except Exception as e: self.write_log(f"ログ作成失敗: {e}")

        # INIの更新
        self.patch_ini_final(ini_path)
        
        # Twitter初期化(選択時)
        if self.var_tw_reset.get():
            self.create_initial_json(path)
            self.write_log("Twitter認証情報を初期化しました。")
        
        messagebox.showinfo("完了", "セットアップが完了しました。\nEqMaxを再起動してください。")

    def patch_ini_final(self, ini_path):
        with open(ini_path, 'r', encoding='utf-8-sig') as f:
            lines = f.readlines()

        S = "\\t"
        items = ["", "[緊急地震速報：]", "報番号", "最終報", "警報", "<改行>", "[震源地：]", "震央名", "[(]", "緯度経度", "[)]", "<改行>", "[マグニチュード：M]", "マグニチュード", "<改行>", "[深さ：]", "深さ", "<改行>", "[推定最大震度：]", "最大震度", "<改行>", "<改行>", "画像"]
        eew_items_line = "EEWItems=" + S.join(items)

        updates = {
            "TwitterBotEnabled": "1", "EEWEnabled": "1", "Enable": "1", "v2": "1",
            "AppName": "EqMax_Discord", "AutoPost": "1", "UploadImage": "1", "AutoCapture": "1",
            "Format": "緊急地震速報：$Point$ $MaxShindo$ $Mag$ $Depth$",
            "CheckTweetCount": "1" if self.var_check_count.get() else "0"
        }

        # Twitter未使用者向け認証情報初期化
        if self.var_tw_reset.get():
            updates.update({
                "ConsumerKey": "", "ConsumerKeySecret": "", "AccessToken": "", "AccessTokenSecret": "",
                "ClientID": "dummy", "ClientSecret": "dummy", "RefreshToken": "dummy", "BearerToken": "dummy",
                "BearerObtainedAt": ""
            })

        new_lines = []
        applied_keys = set()
        for line in lines:
            line_s = line.strip()
            found = False
            if line_s.startswith("EEWItems="):
                new_lines.append(eew_items_line + "\n")
                applied_keys.add("EEWItems")
                found = True
            else:
                for k, v in updates.items():
                    if line_s.startswith(k + "="):
                        new_lines.append(f"{k}={v}\n")
                        applied_keys.add(k)
                        found = True
                        break
            if not found:
                new_lines.append(line if line.endswith('\n') else line + '\n')
        
        for k, v in updates.items():
            if k not in applied_keys: new_lines.append(f"{k}={v}\n")

        with open(ini_path, 'w', encoding='utf-8-sig', newline='\r\n') as f:
            f.writelines(new_lines)
        self.write_log("EqMax.ini の設定を更新しました。")

    def create_initial_json(self, path):
        json_path = os.path.join(path, "v2_Tokens.json")
        data = {"appname": "EqMax_Discord", "client_id": "dummy", "client_id_secret": "dummy", "scopes": "tweet.read tweet.write users.read offline.access media.write", "refresh_token": "dummy", "bearer_token": "dummy", "bearer_token_obtained_at": datetime.now().strftime("%Y-%m-%dT%H:%M:%S.000+09:00")}
        with open(json_path, 'w', encoding='utf-8') as f: json.dump(data, f, indent=4)

if __name__ == "__main__":
    EqMaxSetupPatcher().mainloop()