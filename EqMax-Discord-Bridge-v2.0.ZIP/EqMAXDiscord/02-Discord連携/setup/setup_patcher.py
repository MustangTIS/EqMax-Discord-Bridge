import customtkinter as ctk
from tkinter import filedialog, messagebox
import json
import os
import shutil
from datetime import datetime
import subprocess

class EqMaxBotDeployer(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("EqMax Discord連携 - ボット配置ツール")
        self.geometry("600x700")

        # 1. パス選択
        self.label_path = ctk.CTkLabel(self, text="1. EqMax.exe があるフォルダを選択してください:")
        self.label_path.pack(pady=(20, 0))
        self.path_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.path_frame.pack(pady=5)
        self.entry_path = ctk.CTkEntry(self.path_frame, width=380)
        self.entry_path.pack(side="left", padx=(0, 5))
        self.btn_browse = ctk.CTkButton(self.path_frame, text="選択...", width=80, command=self.browse_file)
        self.btn_browse.pack(side="left")

        # 2. Webhook URL
        self.label_webhook = ctk.CTkLabel(self, text="2. Discord Webhook URLを入力してください:")
        self.label_webhook.pack(pady=(20, 0))
        self.entry_webhook = ctk.CTkEntry(self, width=470, placeholder_text="https://discord.com/api/webhooks/...")
        self.entry_webhook.pack(pady=5)

        # 3. ショートカットオプション
        self.option_frame = ctk.CTkFrame(self)
        self.option_frame.pack(pady=20, padx=20, fill="x")
        self.label_opt = ctk.CTkLabel(self.option_frame, text="3. オプション設定:", font=("", 12, "bold"))
        self.label_opt.pack(pady=(5, 0), padx=10, anchor="w")
        
        self.var_desktop = ctk.BooleanVar(value=True)
        self.check_desktop = ctk.CTkCheckBox(self.option_frame, text="デスクトップにショートカットを作成する", variable=self.var_desktop)
        self.check_desktop.pack(pady=5, padx=20, anchor="w")

        self.var_startup = ctk.BooleanVar(value=True)
        self.check_startup = ctk.CTkCheckBox(self.option_frame, text="Windows起動時に自動実行する (スタートアップ登録)", variable=self.var_startup)
        self.check_startup.pack(pady=5, padx=20, anchor="w")

        # 実行ボタン
        self.btn_run = ctk.CTkButton(self, text="ボットを配置して完了", fg_color="darkgreen", height=60, command=self.run_deploy)
        self.btn_run.pack(pady=20)

        # ログ
        self.log_view = ctk.CTkTextbox(self, width=540, height=120)
        self.log_view.pack(pady=10)

    def browse_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("EqMax.exe", "EqMax.exe")])
        if file_path:
            self.entry_path.delete(0, "end")
            self.entry_path.insert(0, os.path.dirname(file_path))

    def write_log(self, text):
        self.log_view.insert("end", f"{datetime.now().strftime('%H:%M:%S')} : {text}\n")
        self.log_view.see("end")

    def create_shortcut_wsh(self, target_path, link_full_path):
        """WSHを使用してショートカットを作成"""
        shell = "WScript.Shell"
        vbs = (
            f'Set oWS = CreateObject("{shell}")\n'
            f'Set oLink = oWS.CreateShortcut("{link_full_path}")\n'
            f'oLink.TargetPath = "{target_path}"\n'
            f'oLink.WorkingDirectory = "{os.path.dirname(target_path)}"\n'
            f'oLink.WindowStyle = 7\n' # 7 = 最小化で実行（邪魔にならないように）
            f'oLink.Save'
        )
        vbs_path = os.path.join(os.environ["TEMP"], "create_lnk.vbs")
        with open(vbs_path, "w", encoding="shift-jis") as f:
            f.write(vbs)
        subprocess.run(["cscript", "//nologo", vbs_path], shell=True)
        if os.path.exists(vbs_path): os.remove(vbs_path)

    def run_deploy(self):
        eqmax_dir = self.entry_path.get().strip()
        webhook_url = self.entry_webhook.get().strip()

        if not eqmax_dir or not os.path.isdir(eqmax_dir):
            messagebox.showerror("エラー", "正しいEqMaxのフォルダを選択してください。")
            return
        if not webhook_url.startswith("https://"):
            messagebox.showerror("エラー", "Webhook URLを入力してください。")
            return

        # 1. フォルダ作成とファイルコピー
        bot_dir = os.path.join(eqmax_dir, "Discordbot")
        os.makedirs(bot_dir, exist_ok=True)
        
        base_src = os.path.join(os.path.dirname(__file__), "base")
        bat_name = "eqmax_discord.bat"
        target_bat = os.path.join(bot_dir, bat_name)
        
        for f in ["eqmax_discord.py", bat_name]:
            src_path = os.path.join(base_src, f)
            if os.path.exists(src_path):
                shutil.copy2(src_path, bot_dir)
                self.write_log(f"{f} を配置しました。")

        # 2. config.json生成
        config_path = os.path.join(bot_dir, "config.json")
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump({"webhook_url": webhook_url, "eqmax_dir": eqmax_dir}, f, indent=4, ensure_ascii=False)
        self.write_log("config.json を作成しました。")

        # 3. ショートカット作成（チェックボックスの状態を見る）
        shortcut_file_name = "EqMax-DiscordBot.lnk"
        
        if self.var_desktop.get():
            desktop_path = os.path.join(os.environ["USERPROFILE"], "Desktop", shortcut_file_name)
            self.create_shortcut_wsh(target_bat, desktop_path)
            self.write_log("デスクトップにショートカットを作成しました。")

        if self.var_startup.get():
            startup_path = os.path.join(os.environ["APPDATA"], r"Microsoft\Windows\Start Menu\Programs\Startup", shortcut_file_name)
            self.create_shortcut_wsh(target_bat, startup_path)
            self.write_log("スタートアップに登録しました。")

        messagebox.showinfo("完了", "すべての配置が完了しました。")
        self.destroy()

if __name__ == "__main__":
    EqMaxBotDeployer().mainloop()