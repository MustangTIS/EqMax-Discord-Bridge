import os
import time
import requests
import json
import re

# --- 設定の読み込み関数 ---
def load_config():
    # デフォルト値を config 変数に代入する
    config = {
        "webhook_url": "https://discord.com/api/webhooks/...",
        "eqmax_dir": "C:\\PGF\\EqMax_Win64"
    }
    
    # config.jsonがあれば読み込んで中身を上書き
    if os.path.exists("config.json"):
        try:
            with open("config.json", "r", encoding="utf-8") as f:
                config.update(json.load(f))
        except Exception as e:
            print(f"設定ファイルの読み込み失敗: {e}")
    return config
    
# 設定をロード
config = load_config()
WEBHOOK_URL = config["webhook_url"]
# ログファイルの場所をEqMaxのディレクトリから自動生成
LOG_FILE = os.path.join(config["eqmax_dir"], "Twitter.log")

# --- 以下、ロジック部分は変更なし ---

def get_alert_details(text_block):
    """テキストから情報を抽出。震度0や不明でもMや震源があれば採用する"""
    if "緊急地震速報：" not in text_block:
        return None, None, None

    lines = text_block.strip().split('\n')
    shindo = "不明"
    mag_str = "不明"
    mag_val = 0.0
    clean_lines = []
    found_essential = False 
    
    for line in lines:
        line = line.strip()
        if any(x in line for x in ["PostTweet", "TTwitter", "=", "remaining"]): continue
        if not line: continue
        if "尚、これは" in line: break
        
        if "震源地：" in line:
            found_essential = True
        if "推定最大震度：" in line:
            shindo = line.split("：")[1].strip()
        if "マグニチュード：" in line:
            mag_str = line.split("：")[1].strip()
            m_match = re.search(r"(\d+\.\d+|\d+)", mag_str)
            if m_match:
                mag_val = float(m_match.group(1))
                found_essential = True
        
        clean_lines.append(line)

    if not found_essential:
        return None, None, None

    description = "\n".join(clean_lines)
    title = f"[EqMax] EEW Alert📢 【最大震度 {shindo} / {mag_str}】"

    color = 0x808080
    if "7" in shindo: color = 0xFF0000
    elif "6強" in shindo: color = 0xFF4500
    elif "6弱" in shindo: color = 0xFF8C00
    elif "5強" in shindo: color = 0xFFA500
    elif "5弱" in shindo: color = 0xFFFF00
    elif "4" in shindo: color = 0x00FF00
    elif "3" in shindo: color = 0x00FFFF
    elif "2" in shindo: color = 0x1E90FF
    elif "1" in shindo: color = 0xFFFFFF
    
    tsunami_keywords = ["海域", "近海", "沖", "灘", "湾"]
    if any(k in description for k in tsunami_keywords):
        if mag_val >= 7.5:
            description = "🚨**【巨大地震・大津波警戒】大規模な津波が発生する恐れがあります。ただちに海岸から離れ、高い場所へ避難してください。**\n\n" + description
            color = 0xff0000
        elif mag_val >= 6.0:
            description = "⚠️**大規模な海域地震です。津波の発生に厳重に警戒してください。**\n\n" + description
            color = 0xffa500
        else:
            description = "ℹ️海域で地震が発生しました。念のため津波の有無に注意してください。\n\n" + description

    return title, description, color

def process_log_update(content):
    pattern = re.compile(r"(緊急地震速報：.*?)(C:\\.*?\.png)", re.DOTALL)
    matches = pattern.findall(content)
    if not matches: return

    full_text, image_path = matches[-1]
    image_path = image_path.strip()
    
    title, description, color = get_alert_details(full_text)
    if not title: return

    payload = {
        "embeds": [{
            "title": title, "description": description, "color": color,
            "image": {"url": "attachment://image.png"},
            "footer": {"text": "EqMax Realtime Alert (Twitter.log Mode)"}
        }]
    }

    try:
        if os.path.exists(image_path):
            with open(image_path, "rb") as f:
                files = {"file": ("image.png", f, "image/png")}
                requests.post(WEBHOOK_URL, data={"payload_json": json.dumps(payload)}, files=files)
        else:
            requests.post(WEBHOOK_URL, json=payload)
        print(f"送信完了: {title}")
    except Exception as e:
        print(f"送信失敗: {e}")

def watch_log():
    if not WEBHOOK_URL:
        print("エラー: Webhook URLが設定されていません。config.jsonを確認してください。")
        return

    print(f"監視システム起動: {LOG_FILE}")
    last_size = os.path.getsize(LOG_FILE) if os.path.exists(LOG_FILE) else 0
    pending_block = ""
    
    while True:
        try:
            if not os.path.exists(LOG_FILE):
                last_size = 0
                time.sleep(1)
                continue

            current_size = os.path.getsize(LOG_FILE)
            if current_size < last_size:
                last_size = 0
                pending_block = ""
            
            if current_size > last_size:
                with open(LOG_FILE, "r", encoding="utf-8", errors="ignore") as f:
                    f.seek(last_size)
                    new_lines = f.readlines()
                
                for line in new_lines:
                    line = line.strip()
                    if not line: continue
                    if "PostTweet - passed:" in line:
                        pending_block = "" 
                        continue
                    if "緊急地震速報：" in line:
                        pending_block = line + "\n"
                    elif pending_block:
                        pending_block += line + "\n"
                        if ".png" in line and "C:\\" in line:
                            time.sleep(2)
                            process_log_update(pending_block)
                            pending_block = ""
                
                last_size = current_size
        except Exception as e:
            print(f"エラー: {e}")
        time.sleep(1)

if __name__ == "__main__":
    watch_log()