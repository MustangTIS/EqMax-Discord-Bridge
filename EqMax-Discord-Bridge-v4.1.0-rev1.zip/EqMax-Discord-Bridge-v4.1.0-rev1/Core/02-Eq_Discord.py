# -*- coding: utf-8 -*-
import customtkinter as ctk
import tkinter as tk
from tkinter import filedialog, messagebox
import json
import os
import shutil
from datetime import datetime
import subprocess

class EqMaxBotDeployer(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")  # ダークモードに固定
        # Title: EqMax 多機能通知連携 - ボット配置ツール
        self.title("EqMax \u591a\u6a5f\u80fd\u901a\u77e5\u9023\u643a - \u30dc\u30c3\u30c8\u914d\u7f6e\u30c4\u30fc\u30eb")
        self.geometry("750x850")

        self.context_menu = tk.Menu(self, tearoff=0)
        self.context_menu.add_command(label="\u8cbc\u308a\u4ed8\u3051", command=self.paste_to_entry)

        # 1. Path Selection
        self.label_path = ctk.CTkLabel(self, text="1. EqMax.exe \u304c\u3042\u308b\u30d5\u30a9\u30eb\u30c0\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044:")
        self.label_path.pack(pady=(20, 0))
        self.path_frame = ctk.CTkFrame(self, fg_color="transparent")
        self.path_frame.pack(pady=5)
        self.entry_path = ctk.CTkEntry(self.path_frame, width=530)
        self.entry_path.pack(side="left", padx=(0, 5))
        self.btn_browse = ctk.CTkButton(self.path_frame, text="\u9078\u629e...", width=80, command=self.browse_file)
        self.btn_browse.pack(side="left")

        # 2. Webhook URLs
        self.label_webhook = ctk.CTkLabel(self, text="2. \u9001\u4fe1\u5148Webhook (\u6700\u59275\u3064) \u3068\u901a\u77e5\u5f62\u5f0f\u3092\u9078\u629e\u3057\u3066\u304f\u3060\u3055\u3044:", font=("", 12, "bold"))
        self.label_webhook.pack(pady=(20, 5))
        
        self.webhook_entries = []
        self.style_options = ["embed", "simple"]

        for i in range(5):
            frame = ctk.CTkFrame(self)
            frame.pack(pady=3, padx=20, fill="x")
            entry = ctk.CTkEntry(frame, placeholder_text=f"URL {i+1}", width=480)
            entry.pack(side="left", padx=10, pady=10)
            entry.bind("<Button-3>", lambda e, en=entry: self.show_context_menu(e, en))
            style_var = ctk.StringVar(value="embed")
            combo = ctk.CTkOptionMenu(frame, values=self.style_options, variable=style_var, width=100)
            combo.pack(side="right", padx=10)
            self.webhook_entries.append({"entry": entry, "style": style_var})

        # 3. Options
        self.option_frame = ctk.CTkFrame(self)
        self.option_frame.pack(pady=20, padx=20, fill="x")
        self.var_desktop = ctk.BooleanVar(value=True)
        self.check_desktop = ctk.CTkCheckBox(self.option_frame, text="\u30c7\u30b9\u30af\u30c8\u30c3\u30d7\u306b\u30b7\u30e7\u30fc\u30c8\u30ab\u30c3\u30c8\u3092\u4f5c\u6210\u3059\u308b", variable=self.var_desktop)
        self.check_desktop.pack(pady=5, padx=20, anchor="w")
        self.var_startup = ctk.BooleanVar(value=True)
        self.check_startup = ctk.CTkCheckBox(self.option_frame, text="Windows\u8d77\u52d5\u6642\u306b\u81ea\u52d5\u5b9f\u884c\u3059\u308b", variable=self.var_startup)
        self.check_startup.pack(pady=5, padx=20, anchor="w")

        # Run Button
        self.btn_run = ctk.CTkButton(self, text="\u30dc\u30c3\u30c8\u3092\u914d\u7f6e\u3057\u3066\u8a2d\u5b9a\u4fdd\u5b58", fg_color="darkgreen", height=60, command=self.run_deploy)
        self.btn_run.pack(pady=20)

        # --- ログ表示 (背景をグレーにし、緑の文字で視認性を確保) ---
        self.log_view = ctk.CTkTextbox(
            self, 
            width=690, 
            height=120, 
            fg_color="#333333",    # グレー背景
            text_color="#00FF00",  # 明るい緑
            border_width=1,
            border_color="#555555",
            font=("Consolas", 12)  # 等幅フォント
        )
        self.log_view.pack(pady=10)

    def browse_file(self):
        file_path = filedialog.askopenfilename(filetypes=[("EqMax.exe", "EqMax.exe")])
        if file_path:
            self.entry_path.delete(0, "end")
            self.entry_path.insert(0, os.path.dirname(file_path))

    def write_log(self, text):
        self.log_view.insert("end", f"{datetime.now().strftime('%H:%M:%S')} : {text}\n")
        self.log_view.see("end")

    def show_context_menu(self, event, entry_widget):
        self.active_entry = entry_widget
        self.context_menu.post(event.x_root, event.y_root)

    def paste_to_entry(self):
        try:
            self.active_entry.insert("insert", self.clipboard_get())
        except: pass

    def create_shortcut_wsh(self, target_path, link_full_path):
        base_dir = os.path.dirname(os.path.dirname(__file__))
        icon_path = os.path.join(base_dir, "Assets", "eq-dis.ico")
        t_path = target_path.replace("\\", "\\\\")
        l_path = link_full_path.replace("\\", "\\\\")
        i_path = icon_path.replace("\\", "\\\\")
        w_dir = os.path.dirname(target_path).replace("\\", "\\\\")
        vbs = (
            f'Set oWS = CreateObject("WScript.Shell")\n'
            f'Set oLink = oWS.CreateShortcut("{l_path}")\n'
            f'oLink.TargetPath = "{t_path}"\n'
            f'oLink.WorkingDirectory = "{w_dir}"\n'
            f'oLink.IconLocation = "{i_path}"\n'
            f'oLink.WindowStyle = 7\n'
            f'oLink.Save'
        )
        vbs_path = os.path.join(os.environ["TEMP"], "create_lnk_dis.vbs")
        with open(vbs_path, "w", encoding="shift-jis") as f: f.write(vbs)
        subprocess.run(["cscript", "//nologo", vbs_path], shell=True)
        if os.path.exists(vbs_path): os.remove(vbs_path)

    def run_deploy(self):
        eqmax_dir = self.entry_path.get().strip()
        destinations = []
        for item in self.webhook_entries:
            url = item["entry"].get().strip()
            if url.startswith("https://"):
                destinations.append({"url": url, "style": item["style"].get()})

        if not eqmax_dir or not os.path.isdir(eqmax_dir):
            messagebox.showerror("Error", "Folder Error.")
            return
        if not destinations:
            messagebox.showerror("Error", "URL Error.")
            return

        bot_dir = os.path.join(eqmax_dir, "Discordbot")
        os.makedirs(bot_dir, exist_ok=True)
        base_src = os.path.join(os.path.dirname(os.path.dirname(__file__)), "Templates")
        target_bat = os.path.join(bot_dir, "eqmax_discord.bat")
        
        for f in ["eqmax_discord.py", "eqmax_discord.bat"]:
            src = os.path.join(base_src, f)
            if os.path.exists(src):
                shutil.copy2(src, bot_dir)
                self.write_log(f"Copied: {f}")

        config_path = os.path.join(bot_dir, "config.json")
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump({"eqmax_dir": eqmax_dir, "destinations": destinations}, f, indent=4, ensure_ascii=False)
        self.write_log("Saved: config.json")

        lnk_name = "EqMax-Discord\u901a\u77e5\u30dc\u30c3\u30c8.lnk"
        if self.var_desktop.get():
            self.create_shortcut_wsh(target_bat, os.path.join(os.environ["USERPROFILE"], "Desktop", lnk_name))
            self.write_log("Created: Desktop shortcut")
        if self.var_startup.get():
            self.create_shortcut_wsh(target_bat, os.path.join(os.environ["APPDATA"], r"Microsoft\Windows\Start Menu\Programs\Startup", lnk_name))
            self.write_log("Registered: Windows Startup")

        messagebox.showinfo("成功", "書き換え完了")
        self.destroy()

if __name__ == "__main__":
    EqMaxBotDeployer().mainloop()